import { Component } from '@angular/core';
import {ItemService} from "../shared/services/item.service";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent {

}

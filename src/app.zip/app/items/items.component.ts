import { Component } from '@angular/core';
import {ItemService} from "../shared/services/item.service";
import {Item} from "../shared/item.model";

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css'],
})
export class ItemsComponent {


}

import {Component, Input, OnInit} from '@angular/core';
import {ItemService} from "../../shared/services/item.service";
import {Item} from "../../shared/item.model";
import {ActivatedRoute, Router} from "@angular/router";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-item-search-list',
  templateUrl: './item-search-list.component.html',
  styleUrls: ['./item-search-list.component.css']
})
export class ItemSearchListComponent implements OnInit{

  items: Item[] = [];
  dataloaded=false;
  loadtime=1;
  constructor(private http: HttpClient,
              private router: Router,
              private itemService: ItemService,
              private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.items = this.itemService.getSearchedItems();
    this.dataloaded=true;
    // if(this.dataloaded){
    //   this.dataloaded=true;
    //   this.loadtime+=1;
    //   setTimeout(() => {
    //     this.router.navigateByUrl('/items/item-list');
    //     setTimeout(() => {
    //       this.router.navigateByUrl('/items/item-search-list');
    //     }, 100);
    //   }, 100);
    // }
  }

  onSelected(item: Item) {
    this.itemService.itemSelected.emit(item);
  }

  save(){
    if(this.dataloaded){
      this.dataloaded=true;
      this.loadtime+=1;
      setTimeout(() => {
        this.router.navigateByUrl('/items/item-list');
        setTimeout(() => {
          this.router.navigateByUrl('/items/item-search-list');
        }, 100);
      }, 100);
    }
  }
}

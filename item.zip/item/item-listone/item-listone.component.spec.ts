import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemListoneComponent } from './item-listone.component';

describe('ItemListoneComponent', () => {
  let component: ItemListoneComponent;
  let fixture: ComponentFixture<ItemListoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemListoneComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ItemListoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { ItemService } from '../item.service';
@Component({
  selector: 'app-item-listone',
  templateUrl: './item-listone.component.html',
  styleUrls: ['./item-listone.component.css']
})
export class ItemListoneComponent {
  item: any;
  itemid=1;
  constructor(private itemService: ItemService) { }
  get1item({item}: { item: any }) {
    this.itemid = item;
    // 将要获取的商品ID
    this.itemService.getOneItembyId(this.itemid).subscribe(data => {
      this.item = data.rows[0];
    });
  }
}

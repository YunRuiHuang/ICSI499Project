import { Component } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-item-search',
  templateUrl: './item-search.component.html',
  styleUrls: ['./item-search.component.css']
})
export class ItemSearchComponent {
  body={item_keyword:''};
  constructor(private http: HttpClient) { }

  onSubmit(){
    this.http.get('localhost:3001/item/').subscribe(() => {
      console.log('item deleted.');
      this.body = {item_keyword:''};
    })
  }
}

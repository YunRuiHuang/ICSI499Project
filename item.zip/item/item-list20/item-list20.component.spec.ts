import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemList20Component } from './item-list20.component';

describe('ItemList20Component', () => {
  let component: ItemList20Component;
  let fixture: ComponentFixture<ItemList20Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemList20Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ItemList20Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

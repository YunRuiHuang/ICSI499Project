import { forkJoin } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { ItemService } from '../item.service';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-item-list20',
  templateUrl: './item-list20.component.html',
  styleUrls: ['./item-list20.component.css']
})
export class ItemList20Component implements OnInit {
  items: any[] = []; // 用于保存物品列表的数组

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    const itemIds = [1, 2, 3, 4, 5];
    const urls = itemIds.map(id => `http://127.0.0.1:3001/item/itemid/${id}`);

    forkJoin(urls.map(url => this.http.get(url))).subscribe((data: any[]) => {
      this.items = data.map(item => item.rows[0]);
    });
  }
}

import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {forkJoin, Observable} from 'rxjs';
import {map, catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  private apiUrl = 'http://127.0.0.1:3001/item';
  item: any;

  constructor(private http: HttpClient) {
  }

  // getFirstFiveItems(): Observable<any[]> {
  //   const startId = 1; // 起始物品ID
  //   const endId = 5; // 结束物品ID
  //   const url = `${this.apiUrl}/itemid/${startId}-${endId}`; // 构建API请求URL
  //   return this.http.get<any[]>(url);
  // }
  getTopFiveItems(): Observable<any[]> {
    const urls = ['/itemid/1', '/itemid/2', '/itemid/3', '/itemid/4', '/itemid/5'];
    const requests = urls.map(url => this.http.get(`${this.apiUrl}${url}`));
    return forkJoin(requests).pipe(
      map((responses: any[]) => responses.map(response => ({
        itemName: response[0].itemName,
        itemLocation: response[0].itemLocation
      })))
    );
  }

  getOneItembyId(itemId: number): Observable<any> {
    const url = `${this.apiUrl}/itemid/${itemId}`;
    return this.http.get(`url`);
  }
}

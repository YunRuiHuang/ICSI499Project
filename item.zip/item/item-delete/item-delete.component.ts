import { Component } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-item-delete',
  templateUrl: './item-delete.component.html',
  styleUrls: ['./item-delete.component.css']
})
export class ItemDeleteComponent {
  id='';
  constructor(private http: HttpClient) {
  }
  onSubmit(){
    const url = `localhost:3001/item/${this.id}`;
    this.http.delete(url).subscribe(() => {
      console.log('item deleted.');
    })
  }
}

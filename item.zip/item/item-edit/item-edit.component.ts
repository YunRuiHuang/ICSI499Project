import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent {
  body={item_name:'',item_location:'',user_id:''};
  id='';
  constructor(private http: HttpClient) {
  }
  onSubmit(){
    const url = `localhost:3001/item/${this.id}`;
    this.http.put(url, {body: this.body}).subscribe(() => {
      console.log('item edited.');
      this.body = {item_name:'',item_location:'',user_id:''};
    })
  }
}

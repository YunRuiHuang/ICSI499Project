import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemGetbyUserComponent } from './item-getby-user.component';

describe('ItemGetbyUserComponent', () => {
  let component: ItemGetbyUserComponent;
  let fixture: ComponentFixture<ItemGetbyUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItemGetbyUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ItemGetbyUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

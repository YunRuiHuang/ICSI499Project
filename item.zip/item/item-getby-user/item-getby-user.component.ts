import { Component,OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-item-getby-user',
  templateUrl: './item-getby-user.component.html',
  styleUrls: ['./item-getby-user.component.css']
})
export class ItemGetbyUserComponent implements OnInit{
  @Input() userId=1; // declare input property for user ID
  items: any[] = [];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    const url = `http://127.0.0.1:3001/item/userid/${this.userId}`;

    this.http.get(url).subscribe((data: any) => {
      this.items = data.rows;
    });
  }
}
